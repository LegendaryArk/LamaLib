#pragma once

#include "okapi/api.hpp"
#include "../../controller/motionprofiling.hpp"
#include "../../controller/odometry.hpp"
#include "../../controller/pid.hpp"

using namespace std;

namespace lamaLib {
/**
 * @brief The measurements of the chassis: the wheel diameter and the gear ratio
 */
struct ChassisScales {
    double wheelDiameter;
	okapi::AbstractMotor::GearsetRatioPair gearset {okapi::AbstractMotor::gearset::green, 1};

	const double MAX_VEL = gearset.internalGearset == okapi::AbstractMotor::gearset::red ? 100 :
							gearset.internalGearset == okapi::AbstractMotor::gearset::green ? 200 :
							600;
};

class Chassis {
	public:
	/**
	 * @brief Moves forward for a certain amount of meters.
	 * 
	 * @param idist The distance in meters
	 * @param ipoints Starting velocity and ending velocities; used for cutoff; velocities are in m/s
	 */
	virtual void moveDistance(double idist, vector<MotionPoint> ipoints) = 0;

	/**
	 * @brief An absolute pid turn
	 * 
	 * @param iangle The absolute target angle
	 * @param ivel The speed of the turn in m/s
	 * @param ipid The PID gains used for the turn
	 */
	virtual void turnAbsolute(double iangle, double ivel, PIDGains ipid) = 0;
	/**
	 * @brief A relative pid turn
	 * 
	 * @param iangle The relative target angle
	 * @param ivel The speed of the turn in m/s
	 * @param ipid The PID gains used for the turn
	 */
	virtual void turnRelative(double iangle, double ivel, PIDGains ipid) = 0;

	/**
	 * @brief Moves towards a certain point on the field using odometry or GPS sensor
	 * 
	 * @param itarget The target coordinate
	 * @param ipoints Starting velocity and ending velocities; used for cutoff; velocities are in m/s
	 * @param iturnVel The velocity of the turn
	 * @param iturnPid The PID gains used for the turn
	 * @param idecelRangeOffset The offset to the range around the target pose to start decelerating at
	 */
	virtual void moveToPose(Pose itarget, vector<MotionPoint> ipoints, double iturnVel, PIDGains iturnPid, double idecelRangeOffset) = 0;

	/**
	 * @brief Gets the brake mode of the motors
	 * Coast: can be pushed or pulled, the robot will continue moving from momentum after a movement
	 * Brake: will stop after a movement, but will still be able to be pushed or pulled afterwards
	 * Hold: will apply force so the motor stays in place, even after a movement
	 * 
	 * @return The brake mode of the motors
	 */
	virtual okapi::AbstractMotor::brakeMode getBrakeMode() = 0;
	/**
	 * @brief Sets the brake mode of the motors
	 * Coast: can be pushed or pulled, the robot will continue moving from momentum after a movement
	 * Brake: will stop after a movement, but will still be able to be pushed or pulled afterwards
	 * Hold: will apply force so the motor stays in place, even after a movement
	 * 
	 * @param ibrakeMode The brake mode of the motors
	 */
	virtual void setBrakeMode(okapi::AbstractMotor::brakeMode ibrakeMode) = 0;

	/**
	 * @brief Gets the odometry object to access the current pose and calibration methods
	 * 
	 * @return The odometry object that was created for the current chassis
	 */
	shared_ptr<Odometry> getOdom();

	/**
	 * @brief Starts the odom task
	 */
	void startOdom();
	/**
	 * @brief Ends the odom task
	 */
	void endOdom();

	protected:
	shared_ptr<Odometry> odom;
};
} // namespace lamalib