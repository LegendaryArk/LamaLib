#pragma once

#include "api.h"

namespace lamaLib {
class Vision : public pros::Vision {
    public:
    /**
    * @brief The vision sensor is a low quality camera that can see "blobs" of colour specified through colour signatures, calibrated with the V5 Vision Utlitiy
    *
	* To calibrate with the V5 Vision Utility, see: https://kb.vex.com/hc/en-us/articles/360035951911-Using-the-Vision-Utility-with-the-V5-Vision-Sensor
	* 
    * @param vPort The port of the vision sensor
    **/
    Vision(int iport);
	Vision(pros::Vision ivision);

    /**
     * @brief Sets signatures in vision sensor memory to the signatures in the brain memory.
	 * Make sure to use signature_from_utility before using this method to convert the signature from the V5 Vision Utility to the pros signature
     * 
     * @param inputSigs An array of pros::vision_signature_s_t of size 7 to be assigned into the vision sensor
     */
	void setSignature(std::string ikey, pros::vision_signature_s_t isig);
    
	/**
     * @brief Gets the middle coordinate of a specificed largest object with the specified colour signature key.
     * 
     * @param ikey The key that corresponds to the colour signature that was assigned with setSignature()
	 * @param inumLargest The nth largest object. The default is 1, being the largest object
	 * @return The middle coordinate of the nth largest object of the colour signature
     */
    int getMiddle(std::string ikey, int inumLargest = 1);
    /**
     * @brief Gets the weight of a specificed largest object with the specified colour signature key.
     * 
     * @param ikey The key that corresponds to the colour signature that was assigned with setSignature()
	 * @param inumLargest The nth largest object. The default is 1, being the largest object
	 * @return The width of the nth largest object of the colour signature
     */
    int getWidth(std::string ikey, int inumLargest = 1);
	/**
	 * @brief Gets the height of a specificed largest object with the specified colour signature key.
	 * 
	 * @param ikey The key that corresponds to the colour signature that was assigned with setSignature()
	 * @param inumLargest The nth largest object. The default is 1, being the largest object
	 * @return The height of the nth largest object of the colour signature
	 */
	int getHeight(std::string ikey, int inumLargest = 1);
	/**
	 * @brief Gets the left coordinate value of a specificed largest object with the specified colour signature key.
	 * 
	 * @param ikey The key that corresponds to the colour signature that was assigned with setSignature()
	 * @param inumLargest The nth largest object. The default is 1, being the largest object
	 * @return The left coordinate value of the nth largest object of the colour signature
	 */
	int getX(std::string ikey, int inumLargest = 1);
	/**
	 * @brief Gets the top coordinate value of a specificed largest object with the specified colour signature key.
	 * 
	 * @param ikey The key that corresponds to the colour signature that was assigned with setSignature()
	 * @param inumLargest The nth largest object. The default is 1, being the largest object
	 * @return The top coordinate value of the nth largest object of the colour signature
	 */
	int getY(std::string ikey, int inumLargest = 1);

    /**
     * @brief Get the number of objects in the view of the vision sensor.
     * 
     * @return The number of objects in the camera's FOV
     */
    int getCount();

	/**
	 * @brief Sets the LED colour using a hex code
	 * 
	 * @param ihex The hex code of the colour
	 */
	void setLedHex(int ihex);
	/**
	 * @brief Sets the LED colour using a set of RGB value
	 * 
	 * @param ired The red value in the RGB
	 * @param igreen The green value in the RGB
	 * @param iblue The blue value in the RGB
	 */
	void setLedRGB(int ired, int igreen, int iblue);

	/**
	 * @brief Sets the origin of the vision sensor
	 * 
	 * The default is the top left corner
	 * 
	 * @param iorigin The origin position (only options are center and top left corner)
	 */
	void setOrigin(pros::vision_zero_e_t iorigin);

	private:
    std::unordered_map<std::string, pros::vision_signature_s_t> sigs;
};
} // namespace lamaLib