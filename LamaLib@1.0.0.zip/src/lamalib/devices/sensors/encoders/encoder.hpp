#pragma once

namespace lamaLib {
class Encoder {
	public:
	virtual double getTicks() = 0;
	virtual void resetZero() = 0;

	int tpr;
};
} // namespace lamaLib