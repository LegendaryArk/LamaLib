#pragma once

#include "okapi/api.hpp"

namespace lamaLib {
class Controller : public okapi::Controller {
	public:
	Controller(okapi::ControllerId iid = okapi::ControllerId::master);

	/**
	 * @brief Returns whether the digital button has been pressed. It will only return true once per press.
	 * Returns false if the controller is not connected.
	 * 
	 * @param ibtn The button to check 
	 * @return True if the button has not be pressed before, false otherwise. 
	 */
	bool getNewDigital(okapi::ControllerDigital ibtn);

	private:
	int getBtnIndex(okapi::ControllerDigital ibtn);

	bool btnDebounce[12];
};
} // namespace lamaLib