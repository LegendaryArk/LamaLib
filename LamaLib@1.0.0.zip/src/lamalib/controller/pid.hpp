#pragma once

#include "api.h"
#include <cmath>

namespace lamaLib {
struct PIDGains {
    double kp;
    double ki;
    double kd;
    double kf = 0;
	double a = 1;
};

class PIDController {
    public:
    PIDController(PIDGains ipidValues, double imax = 1, double imin = -1, double iiComp = 10, double ileeway = 1);

    double calculatePID(double current, double target);

    bool isComplete();

    void setGains(PIDGains ipidValues);
    PIDGains getGains();
    double getIntegral();
    void setIntegralComp(double iintegralComp);
    double getIntegralComp();
    double getprevError();
    void setMax(double imax);
    double getMax();
    void setMin(double imin);
    double getMin();
    double getCount();
	double getLeeway();
    void resetPID();

    void PIDTuner(bool x, PIDGains ipidValues);
    
    private:
    PIDGains pidValues;

    bool flag_c;
	
    double integral;
    double integralComp;
    double prevError;
    double max;
    double min;
    double count;
	double leeway;
};
}
